<?php

/**
 * Plugin Overviews.
 * @package Maps
 * @author Flipper Code <flippercode>
 **/

//Setup Product Overview Page
    $form  = new WPGMP_Template();
    $productOverviewObj = $form->product_overview();