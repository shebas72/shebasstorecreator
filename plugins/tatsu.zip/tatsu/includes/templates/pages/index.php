<?php

add_action( 'tatsu_register_templates', 'tatsu_register_builtin_page_templates' );
function tatsu_register_builtin_page_templates() {
    
}