<?php
/**
 * Default Header Builder Template
 */

get_header(); 
get_footer(); 
?>