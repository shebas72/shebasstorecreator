<?php
/**
 * WooCommerce Simpe Auctions Ajax Handlers
 *
 * Handles AJAX requests via wp_ajax hook (both admin and front-end events)
 *
 * @category 	Core
 * @version     1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/* Frontend AJAX events */