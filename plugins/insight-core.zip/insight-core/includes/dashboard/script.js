jQuery( document ).ready( function( $ ) {
	$( '#insight_core_featured_themes .inside' ).slick( {
		dots: false,
		arrows: true
	} );
} );
