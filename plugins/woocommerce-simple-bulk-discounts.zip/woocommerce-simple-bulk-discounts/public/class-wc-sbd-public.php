<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://wpgenie.org/
 * @since      1.0.0
 *
 * @package    Wc_Sbd
 * @subpackage Wc_Sbd/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wc_Sbd
 * @subpackage Wc_Sbd/public
 * @author     wpgenie <info@wpgenie.org>
 */
class Wc_Sbd_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */

	public $discount = array();
	public $original_prices = array();

	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Sbd_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Sbd_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wc-sbd-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Sbd_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Sbd_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wc-sbd-public.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function get_discont_for_user($product_id) {

		
		$discont_for_user = false;

		
		$discounts = get_post_meta( $product_id, '_wcsbd_discounts' , true );

		$roles = wp_get_current_user()->roles;

		if(is_array($discounts)){
			foreach ($discounts as $discount) {
				if(in_array($discount['role'], $roles) OR $discount['role'] == 'any' ){
					$discont_for_user[$discount['min_qty']] = $discount;
				}

			}
		}

		if(is_array($discont_for_user)){
				ksort($discont_for_user);
		}

		return $discont_for_user;
	}

	/**
	 * Action before calculate
	 *
	 * @return void
	 */
		public function action_before_calculate() {
			$cart  = WC()->cart;

			if ( sizeof( $cart->cart_contents ) > 0 ) {

				if($this->is_coupon_used() == true) {
					return;
				}

				foreach ( $cart->cart_contents as $cart_item_key => $values ) {
					
					$product_id = $values['product_id'];
					$variation_id = $values['variation_id'];
					$sep_quantity = $values['quantity'];
					$_product = $values['data'];
					if ( get_post_meta( $product_id, "_wc_sbd_enable", true ) != '' && get_post_meta( $product_id, "_wc_sbd_enable", true ) !== 'yes' ) {
						continue;
					}
					$discont_for_user = $this->get_discont_for_user($product_id);
					if($discont_for_user == false){
						continue;
					}

					if($values['variation_id'] != 0 ){
						$quantity = 0;
						foreach ( $cart->cart_contents as $val ) {
							if($val['product_id'] == $product_id){
								$quantity += $val['quantity'];
							}
						}
					} elseif (isset($values['_product_options']) && !empty($values['_product_options'])){
						$quantity = 0;
						foreach ( $cart->cart_contents as $val ) {
							if($val['product_id'] == $product_id){
								$quantity += $val['quantity'];
							}
						}
					} else {
						$quantity = $values['quantity'];
					}

					foreach ($discont_for_user as $key => $value) {

						if ($value['is_variations_sep'] == '1'){
							if($sep_quantity >= $key ){
								$value['qty'] = $sep_quantity;
								if($values['variation_id'] !=0){
									$this->discount[$values['variation_id']] = $value;
								} else{
									$this->discount[$product_id] = $value;
								}
							}
						}else{
							if($quantity >= $key ){
								$value['qty'] = $quantity;
								$this->discount[$product_id] = $value;
							}
						}
					}
					
					if(isset($this->discount[$product_id]) OR isset($this->discount[$variation_id])){
							
								if( version_compare( WC_VERSION, '2.7', "<" ) ) {
									add_filter( 'woocommerce_get_price' , array($this,'get_discount_price'),90,2);
								} else{
									add_filter( 'woocommerce_product_get_price' , array($this,'get_discount_price'),90,2);
									add_filter( 'woocommerce_product_variation_get_price' , array($this,'get_discount_price'),90,2);	
								}	
								
					}
				}

			}	// endif

		}
		/**
		 * Get discount price
		 *
		 * @return float
		 */
		public function get_discount_price($price, $product) {
			
			
			$product_id = $product->get_id();

			$variation_id = ($product->get_type() == 'variation') ? $this->get_parent_id($product_id) : '' ;

			if( !(isset($this->discount[$product_id]) OR  (!empty($variation_id) && isset($this->discount[$variation_id]))) ) {
				return $price;
			}

			$discount_product_id = !empty($variation_id) && isset($this->discount[$variation_id])  ? $variation_id : $product_id;

			$this->original_prices[$product_id]= $price;
			$discount = $this->discount[$discount_product_id];

			if($discount['type'] == '1'){
				$this->discount[$discount_product_id]['discountprice'] = $price * ((100-$discount['discount']) / 100);

				return $this->discount[$discount_product_id]['discountprice'] = $price * ((100-$discount['discount']) / 100);

			} elseif ($discount['type'] == '2'){

				if($discount['is_flat'] == '1')	{

					return $this->discount[$discount_product_id]['discountprice'] = (($price*$discount['qty']- $discount['discount'])/$discount['qty']);
				} else{

					return $this->discount[$discount_product_id]['discountprice'] = $price - $discount['discount'];
				}
			}


		}
		/**
		 * Change subtotal price
		 *
		 * @return float
		 */
		public function change_subtotal_price($product_subtotal, $_product){



			if ( get_option( 'wc-sbd-show-discount-total' , 'yes' ) != 'yes' ) { 	return $product_subtotal;	 }

			$discount_am = 0;

			if ( !(isset($this->discount[$_product['product_id']]) OR  isset($this->discount[$_product['variation_id']])) ) { return $product_subtotal; }

			$product_id = isset($_product['variation_id']) &&  !empty($_product['variation_id']) && isset($this->discount[$_product['variation_id']]) ? $_product['variation_id'] : $_product['product_id'];

			$discount = $this->discount[$product_id];


			if ( $discount['type'] == '1' ) {

				if ( isset($_product['variation_id']) && !empty($_product['variation_id'])  ){
					$original_price = $this->original_prices[ $_product['variation_id'] ];
				} else {
					$original_price = $this->original_prices[ $_product['product_id'] ];
				}
				$discount_am =  ($original_price * $_product['quantity']) * ($discount['discount'] / 100) ;

			} elseif ($discount['type'] == '2') {

				if($discount['is_flat'] == '1')	{
					$discount_am = $discount['discount'] ;
				} else{
					$discount_am = $discount['discount'] * $discount['qty'] ;
				}
			}

			if ( 'excl' === WC()->cart->tax_display_cart ) {
				$discount_am = wc_get_price_excluding_tax( wc_get_product($product_id), array( 'price' => $discount_am ) );
			} 


			$product_subtotal = $product_subtotal.' <span class="wcsbd-subtotal-discount">'.sprintf(__('(incl. %s discount)'), wc_price($discount_am)  ).'<span>';
			return apply_filters( 'wcsbd_subtotal_discount_html', $product_subtotal, $product_subtotal, $_product, $this->discount );
		}
		/**
		 * Change cart item price
		 *
		 * @return string
		 */
		public function change_cart_item_price($price, $product){

				if ( get_option( 'wc-sbd-show-discount-product' , 'yes' ) != 'yes' ) {
					return $price;
				}

				$product_id = $product->get_id();

				if( !(isset($this->discount[$product_id]) OR  ( ($product->get_type() == 'variation') &&  isset($this->discount[$this->get_parent_id($product_id)]) ) )  ) {
					return $price;
				}

				$oldprice = get_post_meta( $product_id, "_price", true );
				if ( 'excl' === WC()->cart->tax_display_cart ) {
					$oldprice = wc_get_price_excluding_tax( $product, array( 'price' => $oldprice ) );
				} 
				if(is_callable('wc_format_sale_price')){
					$newprice = wc_format_sale_price( $oldprice , $price) . $product->get_price_suffix();
				} else{
					$newprice = $product->get_price_html_from_to( $oldprice , $price)  . $product->get_price_suffix();	
				}
				

				$newprice = '<span class="price">'.$newprice.'</span>' ;

				$newprice = apply_filters( 'woocommerce_sale_price_html', $newprice, $product );

				return apply_filters( 'woocommerce_get_price_html', $newprice, $product );
		}
		/**
	     * Remove price filter
		 *
		 * @return void
	     */
	    function remove_price_filter() {

	    	if ( is_cart() OR is_checkout() ) {
	    		return ;
	    	}

	      remove_filter( 'woocommerce_get_price', array($this,'get_discount_price'), 90 );

	      remove_filter( 'woocommerce_product_get_price' , array($this,'get_discount_price'),90,2);
		  remove_filter( 'woocommerce_product_variation_get_price' , array($this,'get_discount_price'),90,2);

		}
		/**
		 * Check if coupon is used in cart
		 *
		 * @return bool
		 */
		protected function is_coupon_used() {

			if ( get_option( 'wc-sbd-coupon', 'yes' ) != 'yes' ) {
				return false;
			}
			return !( empty( WC()->cart->applied_coupons ) );
		}
		/**
		 * Show bulk discount text in product summary
		 *
		 * @return [type] [description]
		 */
		public function bulk_discount_text(){

			global $product,$post;
			$wcsbd_discount_text = get_post_meta( $post->ID, '_wcsbd_discount_text' , true );
			if($wcsbd_discount_text){
					echo apply_filters('the_content',( $wcsbd_discount_text ),$post->ID);
			}
		}
		/**
     * Woocommerce product tabs
     * Used to add tabs to product view page
		 *
     * @param  array $tabs
     * @return array
     */
    function woocommerce_product_tabs($tabs){
	       	global $product;
        $tabs['simple_bulk_discount_tab'] = array(
            'title'    => __('Bulk discount', 'wc-sbd'),
            'priority' => 90 ,
            'callback' => array($this,'render_tab'),
            'content'  => apply_filters('the_content', get_post_meta( $post->ID, '_wcsbd_discount_text' , true )) //this allows shortcodes in custom tabs
        );
        return $tabs;
    }
    /**
     * Render tab
     * Used to render tabs on product view page
		 *
     * @param  string $key
     * @param  array  $tab
     * @return void
     */
    function render_tab($key,$tab){
        global $post;
        echo '<h2>'.apply_filters('wcsbd_tab_title',$tab['title'],$tab,$key).'</h2>';
        echo apply_filters('wcsbd_content',$tab['content'],$tab,$key);
    }
    /**
     * Shortcode for user role bulk discount
		 *
		 * @return string
     */
    function check_user_role( $atts, $content = null ) {
        extract( shortcode_atts( array( 'role' => 'role' ), $atts ) );

        if( current_user_can( $role ) ) {
                return $content;
        }
	}

	/**
     * Get parent id for variation
	 *
	 * @return string
     */
    function get_parent_id( $product_id ) {
    	return wp_get_post_parent_id( $product_id);
	}

}
