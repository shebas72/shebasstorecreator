<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://wpgenie.org/
 * @since      1.0.0
 *
 * @package    Wc_Sbd
 * @subpackage Wc_Sbd/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Wc_Sbd
 * @subpackage Wc_Sbd/includes
 * @author     wpgenie <info@wpgenie.org>
 */
class Wc_Sbd {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Wc_Sbd_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Notices (array)
	 * @var array
	 */
	public $notices = array();

	/**
	 * The minimal version of woocommerce
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    
	 */
	protected $min_wc_version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {

		$this->plugin_name = 'wc-sbd';
		$this->version = '1.0.5';
		$this->min_wc_version = '3.0';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

		add_action( 'admin_notices', array( $this, 'admin_notices' ), 15 );

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Wc_Sbd_Loader. Orchestrates the hooks of the plugin.
	 * - Wc_Sbd_i18n. Defines internationalization functionality.
	 * - Wc_Sbd_Admin. Defines all hooks for the admin area.
	 * - Wc_Sbd_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wc-sbd-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wc-sbd-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wc-sbd-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-wc-sbd-public.php';

		$this->loader = new Wc_Sbd_Loader();
		
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wpgenie-dashboard.php' ;
		
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Wc_Sbd_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Wc_Sbd_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Wc_Sbd_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		if( version_compare( WC_VERSION, '2.7', "<" ) ) {
			$this->loader->add_action( 'woocommerce_product_write_panels', $plugin_admin, 'product_write_panel' );
		} else{
        	$this->loader->add_action( 'woocommerce_product_data_panels', $plugin_admin, 'product_write_panel' );
        }

		$this->loader->add_action( 'wp_ajax_woocommerce_add_wcsbd', $plugin_admin, 'ajax_add_discount_line' );
		$this->loader->add_action( 'wp_ajax_woocommerce_save_wcsbd', $plugin_admin, 'save_discounts_ajax' );
		$this->loader->add_action( 'woocommerce_process_product_meta', $plugin_admin, 'save_discounts',10,2 );

		$this->loader->add_filter( 'woocommerce_product_data_tabs', $plugin_admin, 'product_write_panel_tab',99 );
		$this->loader->add_filter( 'plugin_row_meta', $plugin_admin, 'add_support_link',10,2 );
		$this->loader->add_filter( 'woocommerce_get_settings_pages', $plugin_admin, 'settings_class',20 );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Wc_Sbd_Public( $this->get_plugin_name(), $this->get_version() );

		if(get_option( 'wc-sbd-enable' , 'yes' ) == 'yes'){

			$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
			$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
			$this->loader->add_action( 'woocommerce_after_single_product', $plugin_public, 'get_discont_for_user' );
			$this->loader->add_action( 'woocommerce_before_calculate_totals', $plugin_public, 'action_before_calculate' );
			$this->loader->add_action( 'woocommerce_before_mini_cart', $plugin_public, 'action_before_calculate' );
			$this->loader->add_action( 'woocommerce_cart_item_subtotal', $plugin_public, 'change_subtotal_price' , 90 , 4 );
			$this->loader->add_action( 'woocommerce_after_mini_cart', $plugin_public, 'remove_price_filter' );
			$this->loader->add_action( 'woocommerce_after_calculate_totals', $plugin_public, 'remove_price_filter' );

			$this->loader->add_filter( 'woocommerce_cart_product_price', $plugin_public, 'change_cart_item_price', 90 , 2 );

			if(get_option( 'wc-sbd-show-discount-text' , 'summary' ) == 'tab'){
				$this->loader->add_filter( 'woocommerce_product_tabs', $plugin_public, 'woocommerce_product_tabs' );
			} else{
				$this->loader->add_action( 'woocommerce_single_product_summary', $plugin_public, 'bulk_discount_text', 45 );
			}

		}

		add_shortcode( 'wcsbd_user_role', array($plugin_public, 'check_user_role' ) );
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$environment_warning = self::get_environment_warning();

		if ( $environment_warning  ) {
			$this->add_admin_notice( 'bad_environment', 'error', $environment_warning );
		} else{
			$this->loader->run();	
		}
		
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Wc_Sbd_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

	function get_environment_warning() {
		if ( version_compare( WC_VERSION, $this->min_wc_version, '<' ) ) {
			$message = __( 'WooCommerce Simple Bulk Discounts - The minimum WooCommerce version required for this plugin is %1$s. You are running %2$s.', 'wc-sbd', 'wc-sbd' );
			return sprintf( $message, $min_wc_version, WC_VERSION );
		}
		return false;
	}
	/**
	 * Allow this class and other classes to add slug keyed notices (to avoid duplication)
	 */
	public function add_admin_notice( $slug, $class, $message ) {
		$this->notices[ $slug ] = array(
			'class'   => $class,
			'message' => $message
		);
	}

	/**
	 * Display any notices we've collected thus far (e.g. for connection, disconnection)
	 */
	public function admin_notices() {
		foreach ( (array) $this->notices as $notice_key => $notice ) {
			echo "<div class='" . esc_attr( $notice['class'] ) . "'><p>";
			echo wp_kses( $notice['message'], array( 'a' => array( 'href' => array() ) ) );
			echo "</p></div>";
		}
	}

}
