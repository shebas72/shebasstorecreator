= WooCommerce Simple Bulk Discounts =
Author: wpgenie - https://codecanyon.net/user/wpgenie/portfolio

Documentation: http://wpgenie.org/wc-bulk-discounts/documentation/
Tags: wordpress bulk discounts, woocommerce bulk discounts, simple wordpress bulk discounts, bulk discounts, bulk discounts plugin, wordpress bulk discounts plugin, woocommerce bulk discounts plugin, simple bulk discounts, wpgenie bulk discounts, wpgenie


Requires at least:	4.0
Tested up to:		4.8.1

== Description ==


= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public Licemse.
