<?php global $post, $thepostid; ?>

<div id="wcsbd_tab" class="panel wc-metaboxes-wrapper hidden">
	<div class="toolbar toolbar-top">

		<?php woocommerce_wp_checkbox(array('id' => '_wc_sbd_enable', 'wrapper_class' => '', 'label' => __('Simple bulk discounts enable', 'wc-sbd'),'value' => esc_attr( $enable ) ));?>

		<p class="form-field">
		<label><?php _e('Text input for bulk discount enabled product. It will be shown in product short description. You can use shortcode [wcsbd_user_role role="role"] to show bulk discount text for certain user role that has enabled bulk discount.') ?></label>
		<?php wp_editor( wp_kses_post(get_post_meta( $post->ID, '_wcsbd_discount_text' , true ) ), '_wcsbd_discount_text', array('media_buttons' => false, 'textarea_rows' => '5', 'teeny' => true ) ); ?>
		</p>

		<span class="expand-close">
			<a href="#" class="expand_all"><?php _e( 'Expand', 'wc-sbd' ); ?></a> / <a href="#" class="close_all"><?php _e( 'Close', 'wc-sbd' ); ?></a>
		</span>

		<button type="button" class="button add_wcsbd"><?php _e( 'Add disscount', 'wc-sbd' ); ?></button>
	</div>
	<div class="product_sbd wc-metaboxes discounts">
		<?php
			// Product discounts - taxonomies and custom, ordered, with visibility and variation discounts set
			$discounts = maybe_unserialize( get_post_meta( $thepostid, '_wcsbd_discounts', true ) );
			// Output All Set discounts
			if ( ! empty( $discounts ) ) {
				$discount_keys  = array_keys( $discounts );
				$discount_total = sizeof( $discount_keys );

				for ( $i = 0; $i < $discount_total; $i ++ ) {
					$discount     = $discounts[ $discount_keys[ $i ] ];

					$position      = empty( $discount['position'] ) ? 0 : absint( $discount['position'] );
					$metabox_class = array();

					include(  plugin_dir_path( dirname( __FILE__ ) ) . '/view/html-product-discount.php');;
				}
			}
		?>
	</div>
	<div class="toolbar">
		<span class="expand-close">
			<a href="#" class="expand_all"><?php _e( 'Expand', 'wc-sbd' ); ?></a> / <a href="#" class="close_all"><?php _e( 'Close', 'wc-sbd' ); ?></a>
		</span>
		<button type="button" class="button save_wcsbd button-primary"><?php _e( 'Save discounts', 'wc-sbd' ); ?></button>
	</div>
	<?php do_action( 'woocommerce_product_options_wcsbd' ); ?>
</div>
