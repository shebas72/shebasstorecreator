<?php
global $wp_roles;
$type_for_lab = $discount['type'] == '1' ? '%' : get_woocommerce_currency_symbol();
$roles = $wp_roles->get_names();
$roles = $roles +  array('any' => __( 'Any', 'wc-sbd' ) );

?>
<div class="woocommerce_sbd wc-metabox closed rel="<?php echo $position; ?>">
	<h3>
		<a href="#" class="remove_row delete"><?php _e( 'Remove', 'woocommerce' ); ?></a>
		<div class="handlediv" title="<?php esc_attr_e( 'Click to toggle', 'woocommerce' ); ?>"></div>
		<?php if(isset($discount['min_qty'])) :?>
				<strong class="sbd_discount_name"><?php echo esc_html( __( 'Minimal quantity', 'wc-sbd' ).': '.$discount['min_qty'].', '.__( 'Discount', 'wc-sbd' ).': '.$discount['discount'].$type_for_lab.', '.__( 'User role', 'wc-sbd' ).': '.$roles[$discount['role']] ); ?></strong>
		<?php endif; ?>
	</h3>

	<div class="woocommerce_sbd_data wc-metabox-content">
		<table cellpadding="0" cellspacing="0">
			<tbody>
				<tr>
					<td class="sbd_discount_name">
						<label><?php _e( 'Minimal quantity', 'wc-sbd' ); ?>:</label>

						<input type="number" class="sbd_discount_min_qty" name="sbd_discount_min_qtys[<?php echo $i; ?>]" size="10" value="<?php echo esc_attr( $discount['min_qty'] ); ?>" />

						<input type="hidden" name="sbd_discount_position[<?php echo $i; ?>]" class="sbd_discount_position" value="<?php echo esc_attr( $position ); ?>" />

					</td>
					<td>
						<label><?php _e( 'Discount', 'wc-sbd' ); ?>:</label>
						<input type="number" class="sbd_discount_value" name="sbd_discount_values[<?php echo $i; ?>]" value="<?php echo esc_attr( $discount['discount'] ); ?>"  step="any"/>

					</td>
					<td>
						<label><?php _e( 'Type', 'wc-sbd' ); ?>:</label>
						<select name="sbd_discount_types[<?php echo $i; ?>]">
							<option value="1" <?php selected( $discount['type'], 1 ); ?>><?php _e( 'Percentage', 'wc-sbd' ); ?></option>
							<option value="2" <?php selected( $discount['type'], 2 ); ?>><?php _e( 'Fixed', 'wc-sbd' ); ?></option>

						</select>

					</td>
				</tr>
				<tr>
					<td>
					<label><?php _e( 'User role', 'wc-sbd' ); ?>:</label>

					<select name="sbd_discount_roles[<?php echo $i; ?>]">
							<option value="any"><?php _e( 'Any', 'wc-sbd' ); ?></option>
							<?php wp_dropdown_roles( $discount['role']  ); ?>

					</select>

					</td>
					<td celspan="2">

						<label><input type="checkbox" class="checkbox" <?php checked( $discount['is_flat'], 1 ); ?> name="sbd_is_flat[<?php echo $i; ?>]" value="1" /> <?php _e( 'Flat discount for total (useful only for fixed discounts)', 'wc-sbd' ); ?></label>

						<label><input type="checkbox" class="checkbox" <?php checked( $discount['is_variations_sep'], 1 ); ?> name="sbd_is_variations_sep[<?php echo $i; ?>]" value="1" /> <?php _e( 'Treat product variations separately', 'wc-sbd' ); ?></label>
					</td>
				</tr>

			</tbody>
		</table>
	</div>
</div>
