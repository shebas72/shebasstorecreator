<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://wpgenie.org/
 * @since      1.0.0
 *
 * @package    Wc_Sbd
 * @subpackage Wc_Sbd/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wc_Sbd
 * @subpackage Wc_Sbd/admin
 * @author     wpgenie <info@wpgenie.org>
 */
class Wc_Sbd_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Sbd_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Sbd_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wc-sbd-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts($hook) {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wc_Sbd_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wc_Sbd_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
			$params = array(
				'add_wcsbd_nonce' => wp_create_nonce( 'add-wcsbd' ),
				'save_wcsbd_nonce' => wp_create_nonce( 'save-wcsbd' ),
				'remove_wcsbs' => __('Remove this discount?','wc-sbd'),
			);
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wc-sbd-admin.js', array( 'jquery' ), $this->version, false );

			wp_localize_script( $this->plugin_name, 'woocommerce_wcsbd', $params );
		}	

	}

	/**
	 * Add link to plugin page
     *
	 * @access public
	 * @param  array, string
	 * @return array
     *
	 */
	public function add_support_link($links, $file){
		if(!current_user_can('install_plugins')){
			return $links;
		}


		if($file == 'woocommerce-simple-bulk-discounts/woocommerce-simple-bulk-discounts.php'){
			$links[] = '<a href="http://wpgenie.org/woocommerce-simple-bulk-discounts/documentation/" target="_blank">'.__('Docs', 'wc-sbd').'</a>';
			$links[] = '<a href="http://codecanyon.net/user/wpgenie#contact" target="_blank">'.__('Support', 'wc-sbd').'</a>';
			$links[] = '<a href="http://codecanyon.net/user/wpgenie/" target="_blank">'.__('More WooCommerce Extensions', 'wc-sbd').'</a>';
		}
		return $links;
	}

	/**
	 * Add settings tab to Woocommerce settings page
	 *
	 * @since    1.0.0
     *
	 */
	function settings_class($settings){

		$settings[] = include(  plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wc-settings-wc-sbd.php' );
		return $settings;
	}

	/**
	 * Adds a new tab to the Product Data postbox in the admin product interface
	 *
	 * @return void
   	 *
	 */
	public function product_write_panel_tab($product_data_tabs){

		$wc_sbd_tab = array(
					'wc_sbd_tab' => array(
							'label'  => __('Simple bulk discounts', 'wc-sbd'),
							'target' => 'wcsbd_tab',
							'class'  => array( 'wcsbd_tab',  'hide_if_grouped', 'hide_if_external'),
						),
			);

		return   $product_data_tabs + $wc_sbd_tab;
	}

	/**
	 * Adds the panel to the Product Data postbox in the product interface
	 *
	 * @return void
	 *
	 */
	public function product_write_panel(){

		global $post;
		$product = wc_get_product($post->ID);

		$wc_sbd_enable = get_post_meta( $post->ID, '_wc_sbd_enable' , true );

		if($wc_sbd_enable != 'no') {$enable = 'yes';}  else {$enable = 'no';}


		include(  plugin_dir_path( dirname( __FILE__ ) ) . 'admin/view/html-meta-box-discounts.php');
	}

	public function ajax_add_discount_line(){
		ob_start();

		check_ajax_referer( 'add-wcsbd', 'security' );

		if ( ! current_user_can( 'edit_products' ) ) {
			die(-1);
		}

		$thepostid     = 0;
		$i             = absint( $_POST['i'] );
		$position      = 0;
		$metabox_class = array();

		include(  plugin_dir_path( dirname( __FILE__ ) ) . 'admin/view/html-product-discount.php');
		die();

	}

	/**
	 * Save discounts via ajax.
	 */
	public static function save_discounts($post_id, $post) {

		if ( ! current_user_can( 'edit_products' ) ) {
			return;
		}

		// Save Attributes
		$discounts = array();

		$wc_sbd_enable = isset($_POST['_wc_sbd_enable']) ? esc_attr($_POST['_wc_sbd_enable']) : 'no';
		update_post_meta( $post_id, '_wc_sbd_enable', $wc_sbd_enable );

		$wcsbd_discount_text = isset($_POST['_wcsbd_discount_text']) ? wp_kses_post($_POST['_wcsbd_discount_text']) : '';
		update_post_meta( $post_id, '_wcsbd_discount_text', $wcsbd_discount_text );

		if ( isset( $_POST['sbd_discount_min_qtys'] ) ) {

			$discount_min_qtys  = array_map( 'absint', $_POST['sbd_discount_min_qtys'] );
			$discount_values = isset( $_POST['sbd_discount_values'] ) ? $_POST['sbd_discount_values'] : array();
			$sbd_discount_types = array_map( 'absint', $_POST['sbd_discount_types'] );
			$sbd_discount_roles = isset( $_POST['sbd_discount_roles'] ) ? $_POST['sbd_discount_roles'] : array();
			$sbd_is_flat = isset( $_POST['sbd_is_flat'] ) ? $_POST['sbd_is_flat'] : array();
			$sbd_is_variations_sep = isset( $_POST['sbd_is_variations_sep'] ) ? $_POST['sbd_is_variations_sep'] : array();
			$sbd_discount_position      = $_POST['sbd_discount_position'];
			$discount_min_qtys_max_key = max( array_keys( $discount_min_qtys ) );

			for ( $i = 0; $i <= $discount_min_qtys_max_key; $i++ ) {
				if ( empty( $discount_min_qtys[ $i ] ) ) {
					continue;
				}

				$is_flat   = isset( $sbd_is_flat[ $i ] ) ? 1 : 0;
				$is_variations_sep = isset( $sbd_is_variations_sep[ $i ] ) ? 1 : 0;

				if ( isset( $discount_min_qtys[ $i ] ) ) {

					// Text based, possibly separated by pipes (WC_DELIMITER). Preserve line breaks in non-variation attributes.

					$label =   $discount_min_qtys[ $i ]. $discount_values[ $i ] . $sbd_discount_types[ $i ].$sbd_discount_roles [ $i ];

					// Custom attribute - Add attribute to array and set the values
					$discounts[ md5($label) ] = array(
						'min_qty'           => $discount_min_qtys[ $i ],
						'discount'          => $discount_values[ $i ],
						'type'              => $sbd_discount_types[ $i ],
						'role'              => $sbd_discount_roles[ $i ],
						'position'          => $sbd_discount_position[ $i ],
						'is_flat'           => $is_flat,
						'is_variations_sep' => $is_variations_sep,

					);
				}

			 }
		}

		uasort( $discounts, 'wc_product_attribute_uasort_comparison' );
		update_post_meta( $post_id, '_wcsbd_discounts', $discounts );


	}

	/**
	 * Save discounts via ajax.
	 */
	public static function save_discounts_ajax() {


		check_ajax_referer( 'save-wcsbd', 'security' );

		if ( ! current_user_can( 'edit_products' ) ) {
			die(-1);
		}

		// Get post data
		parse_str( $_POST['data'], $data );
		$post_id = absint( $_POST['post_id'] );

		// Save Attributes
		$discounts = array();
		update_post_meta( $post_id, '_wcsbd_discounts', $discounts );


		if ( isset( $data['sbd_discount_min_qtys'] ) ) {

			$discount_min_qtys  = array_map( 'absint', $data['sbd_discount_min_qtys'] );
			$discount_values = isset( $data['sbd_discount_values'] ) ? $data['sbd_discount_values'] : array();
			$sbd_discount_types = array_map( 'absint', $data['sbd_discount_types'] );
			$sbd_discount_roles = isset( $data['sbd_discount_roles'] ) ? $data['sbd_discount_roles'] : array();
			$sbd_is_flat = isset( $data['sbd_is_flat'] ) ? $data['sbd_is_flat'] : array();
			$sbd_is_variations_sep = isset( $data['sbd_is_variations_sep'] ) ? $data['sbd_is_variations_sep'] : array();
			$sbd_discount_position = $data['sbd_discount_position'];
			$discount_min_qtys_max_key = max( array_keys( $discount_min_qtys ) );

			for ( $i = 0; $i <= $discount_min_qtys_max_key; $i++ ) {
				if ( empty( $discount_min_qtys[ $i ] ) ) {
					continue;
				}

				$is_flat   = isset( $sbd_is_flat[ $i ] ) ? 1 : 0;
				$is_variations_sep = isset( $sbd_is_variations_sep[ $i ] ) ? 1 : 0;


				if ( isset( $discount_min_qtys[ $i ] ) ) {

					// Text based, possibly separated by pipes (WC_DELIMITER). Preserve line breaks in non-variation attributes.

					$label =   $discount_min_qtys[ $i ]. $discount_values[ $i ] . $sbd_discount_types[ $i ].$sbd_discount_roles [ $i ];

					// Custom attribute - Add attribute to array and set the values
					$discounts[ md5($label) ] = array(

						'min_qty'           => $discount_min_qtys[ $i ],
						'discount'          => $discount_values[ $i ],
						'type'              => $sbd_discount_types[ $i ],
						'role'              => $sbd_discount_roles[ $i ],
						'position'          => $sbd_discount_position[ $i ],
						'is_flat'           => $is_flat,
						'is_variations_sep' => $is_variations_sep,

					);
				}

			 }
		}

		uasort( $discounts, 'wc_product_attribute_uasort_comparison' );
		update_post_meta( $post_id, '_wcsbd_discounts', $discounts );

		die();
	}

}
