	jQuery(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 */
	$( 'button.add_wcsbd' ).on( 'click', function() {

		var size         = $( '.product_sbd .woocommerce_sbd' ).length;
		var $wrapper     = $('#wcsbd_tab' );
		var $attributes  = $wrapper.find( '.discounts' );
		var product_type = $( 'select#product-type' ).val();
		var data         = {
			action:   'woocommerce_add_wcsbd',
			security: woocommerce_wcsbd.add_wcsbd_nonce,
			i:        size,
		};

		$wrapper.block({
			message: null,
			overlayCSS: {
				background: '#fff',
				opacity: 0.6
			}
		});

		$.post( woocommerce_admin_meta_boxes.ajax_url, data, function( response ) {
			$attributes.append( response );

			$( document.body ).trigger( 'wc-enhanced-select-init' );

			$wrapper.unblock();

			$( document.body ).trigger( 'woocommerce_added_wcsbd' );
		});		

		return false;
	});

	// Save attributes and update variations.
	$( '.save_wcsbd' ).on( 'click', function() {

		$( '#woocommerce-product-data' ).block({
			message: null,
			overlayCSS: {
				background: '#fff',
				opacity: 0.6
			}
		});

		var data = {
			post_id:  woocommerce_admin_meta_boxes.post_id,
			data:     $( '.product_sbd' ).find( 'input, select,checkbox' ).serialize(),
			action:   'woocommerce_save_wcsbd',
			security: woocommerce_wcsbd.save_wcsbd_nonce
		};

		$.post( woocommerce_admin_meta_boxes.ajax_url, data, function() {
			// Reload variations panel.
			var this_page = window.location.toString();
			this_page = this_page.replace( 'post-new.php?', 'post.php?post=' + woocommerce_admin_meta_boxes.post_id + '&action=edit&' );

			// Load variations panel.
			$( '#variable_product_options' ).load( this_page + ' #variable_product_options_inner', function() {
				$( '#variable_product_options' ).trigger( 'reload' );
			});
			$( '#woocommerce-product-data' ).unblock();
		});
	});

	$( '.product_sbd' ).on( 'click', '.remove_row', function() {
		if ( window.confirm( woocommerce_wcsbd.remove_wcsbs ) ) {
			var $parent = $( this ).parent().parent();

			$parent.find( 'select, input[type=number]' ).val( '' );
			$parent.hide();
			discount_row_indexes();

		}
		return false;
	});

	// Attribute ordering.
	$( '.product_sbd' ).sortable({
		items: '.woocommerce_sbd',
		cursor: 'move',
		axis: 'y',
		handle: 'h3',
		scrollSensitivity: 40,
		forcePlaceholderSize: true,
		helper: 'clone',
		opacity: 0.65,
		placeholder: 'wc-metabox-sortable-placeholder',
		start: function( event, ui ) {
			ui.item.css( 'background-color', '#f6f6f6' );
		},
		stop: function( event, ui ) {
			ui.item.removeAttr( 'style' );
			discount_row_indexes();
		}
	});


	function discount_row_indexes() {

		$( '.product_sbd .woocommerce_sbd' ).each( function( index, el ) {
			$( '.sbd_discount_position', el ).val( parseInt( $( el ).index( '.product_sbd .woocommerce_sbd' ), 10 ) );
		});
	}


});
