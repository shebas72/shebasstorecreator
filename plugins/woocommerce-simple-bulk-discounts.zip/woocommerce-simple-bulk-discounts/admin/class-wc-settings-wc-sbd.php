<?php
/**
 * WooCommerce Simple Storewide Sale Settings
 *
 */


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (  class_exists( 'WC_Settings_Page' ) ) :


class WC_Settings_Simple_Bulk_Discounts extends WC_Settings_Page {

	public function __construct() {
		$this->id    = 'simple_bulk_discounts';
		$this->label = __( 'Simple Bulk Discounts', 'wc-sbd' );

		add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_settings_page' ), 20 );
		add_action( 'woocommerce_settings_' . $this->id, array( $this, 'output' ) );
		add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
	}

	/**
	 * Get settings array
	 *
	 * @return array
	 */
	public function get_settings() {

		$product_categories_select = array();
		$product_tag_select = array();

		$product_categories = get_terms ('product_cat') ;
		$product_tag = get_terms ('product_tag') ;

		foreach ($product_categories as $key => $value) {

			$product_categories_select [$value->term_id] = $value->name;
		}

		foreach ($product_tag as $key => $value) {

			$product_tag_select [$value->term_id] = $value->name;
		}


		return apply_filters( 'woocommerce_' . $this->id . '_settings', array(

			array(	'title' => __( 'Simple Bulk Discounts options', 'wc-sbd' ), 'type' => 'title','desc' => '', 'id' => 'simple_bulk_discounts_options' ),

				array(
					'title' 			=> __( 'Discounts enable', 'wc-sbd' ),
					'desc' 				=> __( 'Enable Simple Bulk Discounts', 'wc-sbd' ),
					'type' 				=> 'checkbox',
					'id'					=> 'wc-sbd-enable',
					'default' 		=> 'yes',
					'desc_tip' 		=>  true,
				),
				array(
					'title' 			=> __( 'Discount disable when coupon is used', 'wc-sbd' ),
					//'desc' 				=> __( '', 'wc-sbd' ),
					'type' 				=> 'checkbox',
					'id'					=> 'wc-sbd-coupon',
					'default' 		=> 'yes',
					'desc_tip' 		=>  true,
				),
				array(
					'title' 			=> __( 'Show bulk discount text', 'wc-sbd' ),
					//	'desc' 				=> __( '', 'wc-sbd' ),
					'type' 				=> 'select',
					'id'					=> 'wc-sbd-show-discount-text',
					'default' 		=> 'summary',
					'options' 		=> array(
					'summary' 		=> __( 'After product summary', 'wc-sbd' ),
					'tab' 				=> __( 'In own tab', 'wc_bulk_discount' ),

					),
					'desc_tip' =>  true,
				),

				array(
					'title' 			=> __( 'Show bulk discount in cart on product level', 'wc-sbd' ),
					//'desc' 				=> __( '', 'wc-sbd' ),
					'type' 				=> 'checkbox',
					'id'					=> 'wc-sbd-show-discount-product',
					'default' 		=> 'yes',
					'desc_tip' 		=>  true,
				),
				array(
					'title' 			=> __( 'Show bulk discount in cart total', 'wc-sbd' ),
					//'desc' 				=> __( '', 'wc-sbd' ),
					'type' 				=> 'checkbox',
					'id'					=> 'wc-sbd-show-discount-total',
					'default' 		=> 'yes',
					'desc_tip' 		=>  true,
				),


				array( 'type' => 'sectionend', 'id' => 'simple_bulk_discounts_options'),

		)); // End pages settings
	}
}
return new WC_Settings_Simple_Bulk_Discounts();

endif;
