<?php
/*
Plugin Name: OT History
Plugin URI: http://oceanthemes.net/
Description: Declares a plugin that will create a custom post type displaying portfolio.
Version: 1.0
Author: OceanThemes History
Author URI: http://oceanthemes.net/
License: GPLv2
*/

// Our History

add_action( 'init', 'register_ocean_History' );

function register_ocean_History() {

    $labels = array( 

        'name' => __( 'History', 'ot_history' ),

        'singular_name' => __( 'History', 'ot_history' ),

        'add_new' => __( 'Add New History', 'ot_history' ),

        'add_new_item' => __( 'Add New History', 'ot_history' ),

        'edit_item' => __( 'Edit History', 'ot_history' ),

        'new_item' => __( 'New History', 'ot_history' ),

        'view_item' => __( 'View History', 'ot_history' ),

        'search_items' => __( 'Search History', 'ot_history' ),

        'not_found' => __( 'No Historys found', 'ot_history' ),

        'not_found_in_trash' => __( 'No Historys found in Trash', 'ot_history' ),

        'parent_item_colon' => __( 'Parent History:', 'ot_history' ),

        'menu_name' => __( 'Our History', 'ot_history' ),

    );



    $args = array( 

        'labels' => $labels,

        'hierarchical' => true,

        'description' => 'List History',

        'supports' => array( 'title', 'editor', 'thumbnail', 'comments', 'post-formats', 'excerpt' ),

        'taxonomies' => array( 'History_category','categories1' ),

        'public' => true,

        'show_ui' => true,

        'show_in_menu' => true,     
        'menu_position' => null,  

        'menu_icon' => 'dashicons-groups',	

        'show_in_nav_menus' => true,

        'publicly_queryable' => true,

        'exclude_from_search' => false,

        'has_archive' => true,

        'query_var' => true,

        'can_export' => true,

        'rewrite' => true,

        'capability_type' => 'post'

    );



    register_post_type( 'History', $args );

}

add_action( 'init', 'History_Categories_hierarchical_taxonomy', 0 );



//create a custom taxonomy name it Skillss for your posts



function History_Categories_hierarchical_taxonomy() {



// Add new taxonomy, make it hierarchical like categories

//first do the translations part for GUI



  $labels = array(

    'name' => __( 'History Categories', 'ot_history' ),

    'singular_name' => __( 'History Categories', 'ot_history' ),

    'search_items' =>  __( 'Search Categories','ot_history' ),

    'all_items' => __( 'All Categories','ot_history' ),

    'parent_item' => __( 'Parent Categories','ot_history' ),

    'parent_item_colon' => __( 'Parent Categories:','ot_history' ),

    'edit_item' => __( 'Edit Categories','ot_history' ), 

    'update_item' => __( 'Update Categories','ot_history' ),

    'add_new_item' => __( 'Add New Categories','ot_history' ),

    'new_item_name' => __( 'New Categories Name','ot_history' ),

    'menu_name' => __( 'Categories','ot_history' ),

  );     



// Now register the taxonomy



  register_taxonomy('categories1',array('History'), array(

    'hierarchical' => true,

    'labels' => $labels,

    'show_ui' => true,

    'show_admin_column' => true,

    'query_var' => true,

    'rewrite' => array( 'slug' => 'categories1' ),

  ));



}

?>