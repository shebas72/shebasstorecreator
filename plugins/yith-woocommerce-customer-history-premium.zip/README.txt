=== YITH WooCommerce Customer History Premium ===

Contributors: yithemes
Tags: woocommerce, customers, history, orders, emails
Requires at least: 4.4
Tested up to: 4.4.2
Stable tag: 1.0.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.0.5 - DEC 30, 2016 =

New: WordPress 4.7 support
New: WooCommerce 2.6.x support
Fix: SQL errors in Quety Monitor
Fix: Refresh live buttons
Fix: Minor bugs
Update: Plugin Framework

= 1.0.4 - SEP 20, 2016 =

New: "Statistics" section
New: Bot detector feature
New: Possibility to delete sessions
New: Sessions "Trash" page
New: Timezone option
Fix: Hidden sessions in user page
Fix: Customers pagination
Fix: Some minor bugs and improvements

= 1.0.3 - SEP 01, 2016 =

Fix: 404 pages in sessions
Fix: Users roles list in network
Fix: Empty users names
Fix: Minor bugs

= 1.0.2 - JUL 26, 2016 =

New: "Other Users" admin section
New: "Searches" admin section
New: "Hide users with no orders" option
New: Sections paginations
Fix: Normal users sessions problem
Fix: Font Awesome action priority

= 1.0.1 - JUN 08, 2016 =

New: YITH WooCommerce Multi Vendor support
New: WooCommerce 2.6.x support

= 1.0.0 - MAY 31, 2016 =

Initial Release
