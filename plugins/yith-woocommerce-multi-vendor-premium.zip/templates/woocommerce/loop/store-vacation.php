<div class="vacation woocommerce-info">
    <i class="fa fa-calendar-times-o" aria-hidden="true"></i>
    <?php echo $vacation_message; ?>
</div>
