<?php
    $custom_style_tag = be_generate_css_from_atts( $values, 'be_portfolio', $key );
?>

</div>
    </div>
    <?php echo $custom_style_tag; ?>
</div>